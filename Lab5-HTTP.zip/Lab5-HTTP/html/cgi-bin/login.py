#!/usr/bin/env python

import cgi

# Predefined username and password for demonstration purposes
valid_username = "test"
valid_password = "p@ssw0rD3"

# Get form data
form = cgi.FieldStorage()
username = form.getvalue('username')
password = form.getvalue('password')

# Check if username and password are valid
if username == valid_username and password == valid_password:
    # Authentication successful
    print("Content-type: text/html")
    print()
    print("<html><head><title>Login Success</title></head><body>")
    print("<h1>Login Successful</h1>")
    print("<p>Welcome, " + username + "!</p>")
    print("</body></html>")
else:
    # Authentication failed
    print("Content-type: text/html")
    print()
    print("<html><head><title>Login Failed</title></head><body>")
    print("<h1>Login Failed</h1>")
    print("<p>Invalid username or password. Please try again.</p>")
    print("</body></html>")