from http.server import HTTPServer, CGIHTTPRequestHandler
import os

class CustomCGIHTTPRequestHandler(CGIHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/login.html":
            # Serve login.html page
            self.path = "/login.html"
            return CGIHTTPRequestHandler.do_GET(self)
        else:
            # Send "Page Not Found" response
            self.send_response(404)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(b"<html><head><title>Page Not Found</title></head>")
            self.wfile.write(b"<body><h1>Page Not Found</h1></body></html>")

os.chdir(r"C:\Users\user\Downloads\Lab5-HTTP\html")
serv = HTTPServer(("", 9000), CustomCGIHTTPRequestHandler)
serv.serve_forever()