
import requests

url_login_page = 'http://localhost:9000/index.html'

data = {
    'username': 'test',  
    'password': 'p@ssw0rD3',  
}

response = requests.get(url_login_page)

if response.status_code == 200:
    
    action_url_index = response.text.find('<form action="')
    action_url_start = action_url_index + len('<form action="')
    action_url_end = response.text.find('"', action_url_start)
    action_url = response.text[action_url_start:action_url_end]

    
    url_login_action = url_login_page.rsplit('/', 1)[0] + '/' + action_url

  
    response = requests.post(url_login_action, data=data)
    response_length = len(response.text.encode('utf-8'))
    if response_length < 200:
        print("content length =", response_length)  
        print(response.text)
    else:
        print("content length =", response_length)
        print("Very large content")
else:
    
    print("Error:", response.status_code)
